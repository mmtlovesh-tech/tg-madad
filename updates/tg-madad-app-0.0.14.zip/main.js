'use strict';
// TG MADAD — приложение для Windows (Electron).
// Внутри работает тот же сервер панели (bundle.js), а интерфейс открывается
// в собственном окне приложения. Закрыли окно — программа продолжает работать
// в фоне (значок у часов) и отвечать клиентам. Полностью выключает пункт
// «Выключить программу» в меню значка или кнопка «Остановить» в панели.
const path = require('path');
const fs = require('fs');
const http = require('http');
const net = require('net');
const { app, BrowserWindow, Tray, Menu, nativeImage, shell, dialog, session, Notification } = require('electron');

const { Updater } = require('./updater');

const APP_ID = 'kz.tgmadad.app';
const ICON = path.join(__dirname, 'icon.png');
const START_HIDDEN = process.argv.includes('--hidden');

// Данные — в той же папке, что и у прежних версий: %LOCALAPPDATA%\TG-MADAD
const DATA = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'TG-MADAD');
fs.mkdirSync(DATA, { recursive: true });
process.env.WA_DESK_ROOT = DATA;
process.env.WA_DESK_ELECTRON = '1';
app.setPath('userData', path.join(DATA, 'app'));
app.setAppUserModelId(APP_ID);
// звук тревоги должен играть сразу, даже если по окну ещё не щёлкали
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

function readSettings() {
  try {
    return JSON.parse(fs.readFileSync(path.join(DATA, 'config', 'settings.json'), 'utf8').replace(/^﻿/, ''));
  } catch (_) {
    return {};
  }
}
const SETTINGS = readSettings();
const PORT = Number(SETTINGS.port) || 3000;

let win = null;
let tray = null;
let url = null;
let quitting = false;
let hintShown = false;

// Только адреса самой панели (http://127.0.0.1:порт) — ничего чужого внутри окна
function isPanelUrl(u) {
  if (!url) return false;
  try { return new URL(u).origin === new URL(url).origin; } catch (_) { return false; }
}
// Ссылки наружу: сайты — в браузере, «Позвонить» — в WhatsApp для Windows
function openOutside(u) {
  try {
    const p = new URL(u).protocol;
    if (['https:', 'http:', 'whatsapp:', 'tel:', 'mailto:'].includes(p)) shell.openExternal(u);
  } catch (_) { /* неверная ссылка */ }
}

// Защита всех окон программы (и главного, и окон с фото/файлами)
app.on('web-contents-created', (_e, wc) => {
  wc.setWindowOpenHandler(({ url: u }) => {
    if (isPanelUrl(u)) return { action: 'allow', overrideBrowserWindowOptions: { icon: ICON, autoHideMenuBar: true, backgroundColor: '#0e1416' } };
    openOutside(u);
    return { action: 'deny' };
  });
  wc.on('will-navigate', (e, u) => {
    if (!isPanelUrl(u)) { e.preventDefault(); openOutside(u); }
  });
  wc.on('will-attach-webview', (e) => e.preventDefault());
});

// Если в настройках задан пароль панели — окно программы входит само
app.on('login', (event, wc, details, authInfo, callback) => {
  const pass = String(readSettings().panelPassword || '');
  if (pass && !authInfo.isProxy && isPanelUrl(details.url)) {
    event.preventDefault();
    callback('admin', pass);
  }
});

function showWindow() {
  if (!url) return;
  if (win) {
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
    return;
  }
  createWindow(true);
}

// Окно создаётся всегда (при автозапуске — скрытым): так звук тревоги
// слышен, даже когда программа свёрнута в значок у часов.
function createWindow(visible) {
  win = new BrowserWindow({
    width: 1320,
    height: 880,
    minWidth: 380,
    minHeight: 520,
    title: 'TG MADAD',
    icon: ICON,
    backgroundColor: '#0e1416',
    autoHideMenuBar: true,
    show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true, webviewTag: false, backgroundThrottling: false }
  });
  win.removeMenu();
  win.loadURL(url);
  if (visible) win.once('ready-to-show', () => win.show());
  win.on('focus', () => win.flashFrame(false));
  win.on('close', (e) => {
    if (quitting) return;
    e.preventDefault();
    win.hide();
    if (!hintShown && tray) {
      hintShown = true;
      tray.displayBalloon({ iconType: 'info', title: 'TG MADAD работает в фоне', content: 'Программа продолжает принимать сообщения и отвечать клиентам. Открыть — двойной щелчок по значку у часов.' });
    }
  });
  win.on('closed', () => { win = null; });
}

function autoStartEnabled() {
  try { return app.getLoginItemSettings({ args: ['--hidden'] }).openAtLogin; } catch (_) { return false; }
}

function buildTray() {
  tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 }));
  tray.setToolTip(`TG MADAD ${app.getVersion()}`);
  const menu = () => Menu.buildFromTemplate([
    { label: 'Открыть TG MADAD', click: showWindow },
    { type: 'separator' },
    {
      label: 'Запускать вместе с Windows',
      type: 'checkbox',
      checked: autoStartEnabled(),
      click: (item) => { app.setLoginItemSettings({ openAtLogin: item.checked, args: ['--hidden'] }); tray.setContextMenu(menu()); }
    },
    { label: 'Открыть папку с данными', click: () => shell.openPath(DATA) },
    { type: 'separator' },
    { label: 'Выключить программу', click: quitAll }
  ]);
  tray.setContextMenu(menu());
  tray.on('double-click', showWindow);
  tray.on('click', showWindow);
}

async function quitAll() {
  quitting = true;
  try { if (global.__waDeskShutdown) await Promise.race([global.__waDeskShutdown(), new Promise((r) => setTimeout(r, 3000))]); } catch (_) { /* выходим всё равно */ }
  app.exit(0);
}

// ---------- старая версия программы ещё работает ----------
function request(method, pathName) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      host: '127.0.0.1', port: PORT, path: pathName, method, timeout: 2500,
      headers: method === 'GET' ? {} : { 'X-WA-Desk': '1', 'Content-Type': 'application/json' }
    }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.end(method === 'GET' ? undefined : '{}');
  });
}
function portFree() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(false));
    s.listen(PORT, '127.0.0.1', () => s.close(() => resolve(true)));
  });
}
// Если на нашем порту работает другая версия TG MADAD (например, старый
// TG-MADAD.exe) — выключаем её, чтобы открылась новая. Данные общие.
async function stopOldVersion() {
  let st;
  try {
    const r = await request('GET', '/api/state');
    st = JSON.parse(r.body);
  } catch (_) {
    return; // порт свободен или там не наша программа
  }
  if (!st || st.app !== 'wa-desk' || st.version === app.getVersion()) return;
  try { await request('POST', '/api/shutdown'); } catch (_) { return; }
  for (let i = 0; i < 50; i++) {
    if (await portFree()) return;
    await new Promise((r) => setTimeout(r, 300));
  }
}

// Тревога «Нужна помощь менеджера»: окно Windows со звуком + мигание значка
const shownNotes = new Set();
function alertManager({ title, body, key }) {
  if (win && !win.isFocused()) win.flashFrame(true);
  const openIt = () => {
    showWindow();
    if (win && key) win.webContents.executeJavaScript(`window.__openChat && window.__openChat(${JSON.stringify(String(key))})`).catch(() => {});
  };
  if (Notification.isSupported()) {
    const n = new Notification({ title: String(title || 'TG MADAD'), body: String(body || '').slice(0, 250), icon: ICON, urgency: 'critical', silent: false, timeoutType: 'never' });
    shownNotes.add(n);
    n.on('click', openIt);
    n.on('close', () => shownNotes.delete(n));
    n.show();
  } else if (tray) {
    tray.displayBalloon({ iconType: 'warning', title: String(title || 'TG MADAD'), content: String(body || '').slice(0, 250) });
    tray.once('balloon-click', openIt);
  }
}

// ---------- распознавание голосовых и фото (невидимое окно) ----------
const REC_DIR = path.join(__dirname, '..', 'recognizer');
const hasRecognizer = fs.existsSync(path.join(REC_DIR, 'index.html'));
if (hasRecognizer) process.env.WA_DESK_RECOGNIZER_DIR = REC_DIR;
let recWin = null;
let recReady = null;
let recQueue = Promise.resolve();
let recIdle = null;
function ensureRecognizer() {
  if (recWin && !recWin.isDestroyed()) return recReady;
  recWin = new BrowserWindow({ show: false, webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false } });
  recReady = new Promise((resolve, reject) => {
    recWin.webContents.once('did-finish-load', resolve);
    recWin.webContents.once('did-fail-load', (_e, _c, d) => reject(new Error(d)));
  });
  recWin.webContents.on('render-process-gone', () => { try { recWin.destroy(); } catch (_) { /* уже закрыто */ } recWin = null; });
  recWin.on('closed', () => { recWin = null; });
  recWin.loadURL(url + '/recognizer/index.html');
  return recReady;
}
function recognize(job) {
  const run = async () => {
    if (!url) throw new Error('программа ещё запускается');
    await ensureRecognizer();
    await recWin.webContents.executeJavaScript('new Promise((r) => { const t = () => (window.TGRecognize ? r() : setTimeout(t, 100)); t(); })', true);
    clearTimeout(recIdle);
    const res = await recWin.webContents.executeJavaScript(`window.TGRecognize(${JSON.stringify(job)})`, true);
    // 20 минут без работы — выгружаем модели, чтобы не занимать память
    recIdle = setTimeout(() => { if (recWin && !recWin.isDestroyed()) recWin.destroy(); recWin = null; }, 20 * 60e3);
    return res;
  };
  const p = recQueue.then(run, run);
  recQueue = p.catch(() => {});
  return p;
}

// ---------- автообновление ----------
const updater = new Updater({
  dataDir: DATA,
  appDir: __dirname,
  currentVersion: app.getVersion(),
  log: (m) => console.log(m),
  onStatus: (st) => { if (global.__waDeskUpdateStatus) global.__waDeskUpdateStatus(st); }
});
async function installUpdateNow() {
  // модель ИИ работает отдельным процессом из папки программы — сначала закрываем её
  if (global.__waDeskStopAi) { try { await global.__waDeskStopAi(); } catch (_) { /* не мешает */ } }
  const v = updater.install();
  console.log(`Обновление до ${v}: перезапуск…`);
  app.relaunch({ args: process.argv.slice(1).filter((a) => a !== '--hidden').concat(win && win.isVisible() ? [] : ['--hidden']) });
  quitAll();
  return v;
}
function startUpdater() {
  setTimeout(() => updater.check().catch(() => {}), 2 * 60e3).unref();
  setInterval(() => {
    updater.check().catch(() => {});
    if (updater.shouldInstallNow()) installUpdateNow().catch((e) => console.error('Обновление:', e.message));
  }, 30 * 60e3).unref();
}

// Связь с сервером панели (server.js)
global.__waDesk = {
  updater: {
    status: () => updater.status(),
    setConfig: (c) => updater.setConfig(c),
    check: () => updater.check({ force: true }),
    installNow: () => installUpdateNow()
  },
  ready(u) {
    url = u;
    if (!win) createWindow(!START_HIDDEN);
    else if (!START_HIDDEN) showWindow();
  },
  alert: alertManager,
  recognize: hasRecognizer ? recognize : null,
  // выбрать файл модели ИИ (.gguf) обычным окном Windows
  async pickFile({ title = 'Выберите файл', filters = [] } = {}) {
    const r = await dialog.showOpenDialog(win && !win.isDestroyed() ? win : undefined, { title, properties: ['openFile'], filters });
    return r.canceled || !r.filePaths.length ? '' : r.filePaths[0];
  },
  fatal(message) {
    dialog.showErrorBox('TG MADAD', String(message));
    app.exit(1);
  }
};

// Новая версия, запущенная поверх старой: старая сама выключается и уступает
// место (так обновление — это просто запуск нового TG-MADAD.exe).
const MY_VERSION = app.getVersion();
function isNewer(a, b) {
  const pa = String(a || '').split('.').map(Number);
  const pb = String(b || '').split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}

function start() {
  let lastShow = 0;
  app.on('second-instance', (_e, _argv, _cwd, data) => {
    if (data && isNewer(data.version, MY_VERSION)) { quitAll(); return; }
    if (Date.now() - lastShow < 15000) return; // повторные попытки той же копии — окно уже показано
    lastShow = Date.now();
    showWindow();
  });
  app.on('window-all-closed', (e) => { if (!quitting) e.preventDefault(); });
  app.on('before-quit', () => { quitting = true; });
  app.whenReady().then(async () => {
    // микрофон (голосовые) — только для окна самой программы
    const ALLOWED = ['media', 'clipboard-sanitized-write', 'notifications', 'fullscreen'];
    session.defaultSession.setPermissionRequestHandler((wc, permission, cb, details) => {
      cb(isPanelUrl(details.requestingUrl || wc.getURL()) && ALLOWED.includes(permission));
    });
    session.defaultSession.setPermissionCheckHandler((wc, permission, origin) => isPanelUrl(origin) && ALLOWED.includes(permission));
    buildTray();
    startUpdater();
    await stopOldVersion();
    try {
      require('./bundle.js');
    } catch (e) {
      dialog.showErrorBox('TG MADAD', `Программа не запустилась: ${e.message}`);
      app.exit(1);
    }
  });
}

if (app.requestSingleInstanceLock({ version: MY_VERSION })) {
  start();
} else {
  // уже запущено: если там старая версия — она выключится, ждём до 20 секунд
  let tries = 0;
  const timer = setInterval(() => {
    tries += 1;
    if (app.requestSingleInstanceLock({ version: MY_VERSION })) { clearInterval(timer); start(); }
    else if (tries >= 24) { clearInterval(timer); app.quit(); } // та же версия — первое окно уже показано
  }, 500);
}
