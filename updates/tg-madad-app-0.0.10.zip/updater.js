'use strict';
// Автообновление TG MADAD.
// Раз в N дней (по умолчанию 10) программа смотрит, есть ли новая версия:
//   • GitHub: последний выпуск репозитория (владелец/название), файлы
//     tg-madad-app-<версия>.zip и tg-madad-app-<версия>.sha256;
//   • или любой адрес с файлом latest.json: { version, url, sha256 }.
// Скачивает, проверяет контрольную сумму (файл не испорчен и не подменён),
// распаковывает рядом и ставит: ночью (3:00–5:00) сама или сразу по кнопке.
// Старая версия остаётся в папке resources/app.old-<версия> — на всякий случай.
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const DAY = 86400e3;

function newer(a, b) {
  const pa = String(a || '').replace(/^v/, '').split('.').map(Number);
  const pb = String(b || '').replace(/^v/, '').split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}

function get(url, { json = false, file = null, max = 1024 * 1024 * 1024 } = {}, redirects = 0) {
  return new Promise((resolve, reject) => {
    // обычный http разрешён только для проверки на этом же компьютере
    const lib = /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//.test(url) ? http : https;
    if (lib === https && !/^https:\/\//.test(url)) return reject(new Error('адрес обновлений должен начинаться с https://'));
    const req = lib.get(url, { headers: { 'User-Agent': 'TG-MADAD-updater', Accept: json ? 'application/vnd.github+json, application/json' : '*/*' }, timeout: 60000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects < 5) {
        res.resume();
        return resolve(get(new URL(res.headers.location, url).toString(), { json, file, max }, redirects + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`сервер ответил ${res.statusCode}`)); }
      let size = 0;
      if (file) {
        const out = fs.createWriteStream(file);
        res.on('data', (c) => { size += c.length; if (size > max) { req.destroy(new Error('файл слишком большой')); } });
        res.pipe(out);
        out.on('finish', () => out.close(() => resolve(file)));
        out.on('error', reject);
        res.on('error', reject);
        return;
      }
      const chunks = [];
      res.on('data', (c) => { size += c.length; if (size > 5 * 1024 * 1024) req.destroy(new Error('ответ слишком большой')); else chunks.push(c); });
      res.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf8');
        if (!json) return resolve(body);
        try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('неверный ответ сервера обновлений')); }
      });
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('сервер обновлений не отвечает')));
    req.on('error', reject);
  });
}

function sha256(file) {
  const h = crypto.createHash('sha256');
  h.update(fs.readFileSync(file));
  return h.digest('hex');
}

function unzip(zip, dir) {
  fs.mkdirSync(dir, { recursive: true });
  if (process.platform === 'win32') execFileSync('tar', ['-xf', zip, '-C', dir], { windowsHide: true });
  else execFileSync('unzip', ['-q', '-o', zip, '-d', dir]);
}

class Updater {
  constructor({ dataDir, appDir, currentVersion, log = () => {}, onStatus = () => {} }) {
    this.dataDir = dataDir;
    this.appDir = appDir; // …/resources/app
    this.current = currentVersion;
    this.log = log;
    this.onStatus = onStatus;
    this.file = path.join(dataDir, 'config', 'update.json');
    this.dir = path.join(dataDir, 'updates');
    this.busy = false;
    this.cfg = this._read();
  }

  _read() {
    let c = {};
    try { c = JSON.parse(fs.readFileSync(this.file, 'utf8').replace(/^﻿/, '')); } catch (_) { /* первый запуск */ }
    return {
      source: typeof c.source === 'string' ? c.source.trim() : '',
      intervalDays: Number(c.intervalDays) > 0 ? Math.min(90, Number(c.intervalDays)) : 10,
      auto: c.auto !== false,
      lastCheck: Number(c.lastCheck) || 0,
      lastError: c.lastError || null,
      ready: c.ready && c.ready.version ? c.ready : null,
      installed: c.installed || null
    };
  }
  _save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.cfg, null, 2));
    } catch (e) { this.log('Обновления: настройки не сохранены: ' + e.message); }
    this.onStatus(this.status());
  }

  status() {
    const next = this.cfg.lastCheck ? this.cfg.lastCheck + this.cfg.intervalDays * DAY : null;
    return { current: this.current, source: this.cfg.source, intervalDays: this.cfg.intervalDays, auto: this.cfg.auto, lastCheck: this.cfg.lastCheck || null, nextCheck: next, lastError: this.cfg.lastError, ready: this.cfg.ready, busy: this.busy, installed: this.cfg.installed };
  }
  setConfig({ source, intervalDays, auto } = {}) {
    if (source !== undefined) {
      const s = String(source || '').trim();
      if (s && !/^[\w.-]+\/[\w.-]+$/.test(s) && !/^https:\/\/\S+$/.test(s) && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/\S*$/.test(s)) throw new Error('Укажите «владелец/репозиторий» на GitHub или адрес https://…/latest.json');
      this.cfg.source = s;
    }
    if (intervalDays !== undefined) this.cfg.intervalDays = Math.max(1, Math.min(90, Number(intervalDays) || 10));
    if (auto !== undefined) this.cfg.auto = auto !== false;
    this._save();
    return this.status();
  }

  // что лежит на сервере обновлений
  async _latest() {
    const src = this.cfg.source;
    if (/^https?:\/\//.test(src)) {
      const m = await get(src, { json: true });
      if (!m || !m.version || !m.url || !/^[a-f0-9]{64}$/i.test(String(m.sha256 || ''))) throw new Error('в latest.json нет version, url или sha256');
      return { version: String(m.version).replace(/^v/, ''), url: m.url, sha256: m.sha256.toLowerCase(), notes: m.notes || '' };
    }
    const rel = await get(`https://api.github.com/repos/${src}/releases/latest`, { json: true });
    const version = String(rel.tag_name || '').replace(/^v/, '');
    const assets = rel.assets || [];
    const zip = assets.find((a) => /^tg-madad-app-.*\.zip$/i.test(a.name));
    const sum = assets.find((a) => /^tg-madad-app-.*\.sha256$/i.test(a.name));
    if (!version || !zip || !sum) throw new Error('в выпуске на GitHub нет файлов обновления');
    const sha = String(await get(sum.browser_download_url)).trim().split(/\s+/)[0].toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(sha)) throw new Error('неверная контрольная сумма в выпуске');
    return { version, url: zip.browser_download_url, sha256: sha, notes: rel.body || '' };
  }

  // проверить и скачать (не устанавливает)
  async check({ force = false } = {}) {
    if (this.busy) return this.status();
    if (!this.cfg.source) { this.cfg.lastError = 'Не указан адрес обновлений'; this._save(); return this.status(); }
    if (!force && Date.now() - this.cfg.lastCheck < this.cfg.intervalDays * DAY) return this.status();
    this.busy = true;
    this.onStatus(this.status());
    try {
      const l = await this._latest();
      this.cfg.lastCheck = Date.now();
      this.cfg.lastError = null;
      if (!newer(l.version, this.current)) { this.cfg.ready = null; this._save(); return this.status(); }
      if (this.cfg.ready && this.cfg.ready.version === l.version && fs.existsSync(this.cfg.ready.dir)) { this._save(); return this.status(); }
      fs.mkdirSync(this.dir, { recursive: true });
      const zip = path.join(this.dir, `tg-madad-app-${l.version}.zip`);
      this.log(`Обновления: скачиваю версию ${l.version}…`);
      await get(l.url, { file: zip });
      const got = sha256(zip);
      if (got !== l.sha256) { fs.rmSync(zip, { force: true }); throw new Error('скачанный файл повреждён (контрольная сумма не совпала)'); }
      const dir = path.join(this.dir, `app-${l.version}`);
      fs.rmSync(dir, { recursive: true, force: true });
      unzip(zip, dir);
      const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
      if (pkg.version !== l.version || !fs.existsSync(path.join(dir, 'main.js')) || !fs.existsSync(path.join(dir, 'bundle.js'))) throw new Error('в обновлении не хватает файлов программы');
      fs.rmSync(zip, { force: true });
      this.cfg.ready = { version: l.version, dir, notes: String(l.notes || '').slice(0, 2000), at: Date.now() };
      this.log(`Обновления: версия ${l.version} скачана и проверена`);
      this._save();
    } catch (e) {
      this.cfg.lastCheck = Date.now();
      this.cfg.lastError = e.message;
      this.log('Обновления: ' + e.message);
      this._save();
    } finally {
      this.busy = false;
      this.onStatus(this.status());
    }
    return this.status();
  }

  // поставить скачанную версию: старую папку сохраняем рядом, новую — на её место
  install() {
    const r = this.cfg.ready;
    if (!r || !fs.existsSync(r.dir)) throw new Error('Новая версия ещё не скачана');
    const res = path.dirname(this.appDir);
    const old = path.join(res, `app.old-${this.current}`);
    fs.rmSync(old, { recursive: true, force: true });
    try {
      fs.renameSync(this.appDir, old);
    } catch (e) {
      throw new Error(`Нет прав заменить файлы программы (${e.code || e.message}). Распакуйте новую версию вручную.`);
    }
    try {
      fs.renameSync(r.dir, this.appDir);
    } catch (e) {
      fs.renameSync(old, this.appDir); // возвращаем как было
      throw new Error('Не удалось поставить новую версию: ' + e.message);
    }
    // оставляем только одну старую копию
    for (const n of fs.readdirSync(res)) if (/^app\.old-/.test(n) && path.join(res, n) !== old) fs.rmSync(path.join(res, n), { recursive: true, force: true });
    this.cfg.installed = { from: this.current, to: r.version, at: Date.now() };
    this.cfg.ready = null;
    this._save();
    return r.version;
  }

  // ночью, если есть готовое обновление и разрешено ставить само
  shouldInstallNow(now = new Date()) {
    const h = now.getHours();
    return !!(this.cfg.auto && this.cfg.ready && h >= 3 && h < 5);
  }
}

module.exports = { Updater, newer };
