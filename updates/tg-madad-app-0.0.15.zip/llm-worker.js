'use strict';
// Отдельный процесс для модели ИИ (llama.cpp через node-llama-cpp).
// Зачем отдельно: модель — большая программа на C++. Если она упадёт (редкий
// процессор, мало памяти), упадёт только этот процесс — WhatsApp, бот и панель
// продолжают работать, а ИИ просто перезапустится при следующей задаче.
// Запускается из llm.js (child_process.fork); в программе лежит рядом с bundle.js.
const fs = require('fs');
const os = require('os');

// Память (замер 0.0.15 на Qwen3-1.7B): раньше процесс модели занимал ≈2,9 ГБ — модель лежала
// в памяти дважды (файл + переупакованная для процессора копия) и «рабочая память» на 4096 токенов.
// Теперь модель читается один раз (без mmap), рабочая память 2560 токенов: ≈1,7 ГБ.
// Для замеров значения можно менять переменными окружения.
const CTX = Number(process.env.WA_DESK_AI_CTX) || 2560;
const BATCH = Number(process.env.WA_DESK_AI_BATCH) || 256;
const FLASH = process.env.WA_DESK_AI_FLASH === '1';
const MMAP = process.env.WA_DESK_AI_MMAP === '1';

class Engine {
  constructor({ idleMs = 3 * 60e3, onIdle = () => {} } = {}) {
    this.idleMs = idleMs;
    this.onIdle = onIdle;
    this.state = { loaded: false, loading: false, modelPath: '', error: null, lastSpeed: null, engine: null };
    this.grammars = new Map();
  }

  async _lib() {
    if (!this.lib) this.lib = await import('node-llama-cpp'); // в программе: resources/app/node_modules
    return this.lib;
  }

  async _ensure(modelPath, { threads = 0 } = {}) {
    if (this.model && this.state.modelPath === modelPath) return;
    await this._unload();
    if (!modelPath || !fs.existsSync(modelPath)) throw new Error('Файл модели не найден: ' + (modelPath || 'не указан'));
    this.state.loading = true;
    try {
      const { getLlama } = await this._lib();
      const cores = Math.max(1, os.cpus().length);
      // только готовая сборка для процессора: без видеокарты и без сборки из исходников
      this.llama = this.llama || await getLlama({ gpu: false, build: 'never', logLevel: 'error' }).catch((e) => {
        throw new Error('Модуль ИИ не запустился на этом компьютере (' + String(e.message || e).slice(0, 200) + '). Переустановите программу или напишите разработчику.');
      });
      this.model = await this.llama.loadModel({ modelPath, useMmap: MMAP });
      // половина ядер — чтобы компьютер не тормозил, пока ИИ думает
      this.context = await this.model.createContext({
        contextSize: CTX, batchSize: BATCH, flashAttention: FLASH,
        threads: threads > 0 ? threads : Math.max(1, Math.ceil(cores / 2))
      });
      this.state.loaded = true;
      this.state.modelPath = modelPath;
      this.state.error = null;
      this.state.engine = 'llama.cpp (' + (this.llama.buildType || 'prebuilt') + ')';
    } catch (e) {
      this.state.error = e.message;
      await this._unload();
      throw e;
    } finally {
      this.state.loading = false;
    }
  }

  async _unload() {
    clearTimeout(this.idleTimer);
    try { if (this.context) await this.context.dispose(); } catch (_) { /* уже выгружено */ }
    try { if (this.model) await this.model.dispose(); } catch (_) { /* уже выгружено */ }
    this.context = null;
    this.model = null;
    this.grammars.clear();
    this.state.loaded = false;
  }

  async _grammar(schema) {
    const k = JSON.stringify(schema);
    if (!this.grammars.has(k)) this.grammars.set(k, await this.llama.createGrammarForJsonSchema(schema));
    return this.grammars.get(k);
  }

  async ask({ modelPath, threads, system, user, schema, maxTokens = 300, temperature = 0.3, timeoutMs = 180e3 }) {
    user = String(user || '');
    await this._ensure(modelPath, { threads });
    clearTimeout(this.idleTimer);
    const { LlamaChatSession } = await this._lib();
    const seq = this.context.getSequence();
    const t0 = Date.now();
    let tokens = 0;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const budget = CTX - maxTokens - 96;
      for (let k = 0; k < 6 && this.model.tokenize(`${system || ''}\n${user}`).length > budget; k++) {
        const cut = Math.ceil(user.length * 0.15);
        const mid = Math.floor(user.length * 0.45);
        user = user.slice(0, mid - Math.floor(cut / 2)) + '\n…\n' + user.slice(mid + Math.ceil(cut / 2));
      }
      const session = new LlamaChatSession({ contextSequence: seq, systemPrompt: system });
      const grammar = schema ? await this._grammar(schema) : undefined;
      // «/no_think» — Qwen3 отвечает сразу, без длинных рассуждений
      const raw = await session.prompt(`${user}\n/no_think`, { maxTokens, temperature, grammar, signal: ctrl.signal, stopOnAbortSignal: true, onToken: (t) => { tokens += t.length; } });
      const text = String(raw || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
      const ms = Date.now() - t0;
      this.state.lastSpeed = { tokens, ms, perSec: ms ? +(tokens / (ms / 1000)).toFixed(1) : 0, at: Date.now() };
      let json = null;
      if (schema) {
        const i = text.indexOf('{');
        const j = text.lastIndexOf('}');
        try { json = JSON.parse(i >= 0 && j > i ? text.slice(i, j + 1) : text); } catch (_) { json = null; }
        if (!json) this.state.lastBad = text.slice(0, 300);
      }
      return { text, json, ms, tokens };
    } finally {
      clearTimeout(timer);
      seq.dispose();
      // не нужен 3 минуты — освобождаем память
      this.idleTimer = setTimeout(() => { this._unload().then(() => this.onIdle(), () => this.onIdle()); }, this.idleMs);
    }
  }
}

// ---------- процесс-исполнитель: задачи приходят по IPC от llm.js ----------
if (require.main === module && typeof process.send === 'function') {
  const idleMs = Number(process.env.WA_DESK_AI_IDLE_MS) || 3 * 60e3; // не нужен 3 минуты — память освобождается
  // простаивает — процесс завершается сам (память компьютера свободна целиком)
  let lastMsgAt = Date.now();
  let busy = 0;
  // завершаемся, только если за это время не пришло новых задач
  const engine = new Engine({ idleMs, onIdle: () => { if (!busy && Date.now() - lastMsgAt >= idleMs) process.exit(0); } });
  let chain = Promise.resolve();
  process.on('message', (m) => {
    if (!m || m.op !== 'ask') return;
    lastMsgAt = Date.now();
    busy += 1;
    clearTimeout(engine.idleTimer);
    chain = chain.then(async () => {
      try {
        const result = await engine.ask(m.args || {});
        process.send({ id: m.id, ok: true, result, state: engine.state });
      } catch (e) {
        process.send({ id: m.id, ok: false, error: String((e && e.message) || e), state: engine.state });
      } finally {
        busy -= 1;
      }
    });
  });
  process.on('disconnect', () => process.exit(0)); // программа закрылась
  process.send({ type: 'ready', pid: process.pid });
}

module.exports = { Engine };
